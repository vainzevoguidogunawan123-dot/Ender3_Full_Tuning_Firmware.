
// Auto-generated simplified Configuration_adv.h for Ender 3 Full Tuning
#define CONFIGURATION_ADV_H_VERSION 020103

#define BABYSTEP_ZPROBE_OFFSET
#define BABYSTEP_ZPROBE_GFX_OVERLAY

#define ADVANCED_PAUSE_FEATURE

#define LIN_ADVANCE
#define EXTRA_LIN_ADVANCE_K 0

#define FAN_MIN_PWM 50

#define E0_AUTO_FAN_PIN -1
