
# Ender 3 Full Tuning Firmware (Auto-generated)
Berisi konfigurasi dasar sesuai spesifikasi:
- Ender 3
- Board 4.2.2
- BLTouch clone
- UBL
- Input Shaping
- Direct Drive
- Linear Rail X/Y
- EEPROM autosave
